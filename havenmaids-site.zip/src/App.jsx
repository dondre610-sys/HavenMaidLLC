import React from 'react'
import HavenMaidsSite from './HavenMaidsSite.jsx'

// Optionally set your logo URL here (must be public HTTPS)
// window.__HAVENMAIDS_LOGO_URL = 'https://example.com/your-logo.png'

export default function App() {
  return <HavenMaidsSite />
}
