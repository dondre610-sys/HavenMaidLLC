# HavenMaids LLC — Website

Deploys to GitHub Pages via GitHub Actions.

## Quick Deploy (GitHub)
1. **Create a new repo** on GitHub — e.g. `havenmaids-site`.
2. **Download this ZIP** and extract it. Initialize git and push:
   ```bash
   cd havenmaids-site
   git init
   git branch -M main
   git remote add origin https://github.com/<your-user>/havenmaids-site.git
   npm ci
   git add -A
   git commit -m "Initial commit"
   git push -u origin main
   ```
3. On GitHub: **Settings → Pages** → Set **Build & deployment** to **GitHub Actions** (the workflow provided will handle deploys).
4. The Action will build and publish your site to `https://<your-user>.github.io/havenmaids-site/`.

## Setting your logo
- Add a public HTTPS logo URL in `src/App.jsx` by setting:
  ```js
  window.__HAVENMAIDS_LOGO_URL = "https://YOUR-DOMAIN/logo.png";
  ```
- Or inject it via a `<script>` tag in `index.html`.
- If the logo fails to load, the UI shows the **HM** monogram.

## Local Dev
```bash
npm ci
npm run dev
```
Open http://localhost:5173/

## Notes
- Tailwind is included via CDN for GitHub Pages simplicity.
- If you later want full Tailwind JIT pipeline, add `tailwindcss` and a PostCSS config.
