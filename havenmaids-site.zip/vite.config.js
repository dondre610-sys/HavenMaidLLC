import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// IMPORTANT: set base to repo name for GitHub Pages (replace 'havenmaids-site' if you rename the repo)
export default defineConfig({
  plugins: [react()],
  base: '/havenmaids-site/'
})
